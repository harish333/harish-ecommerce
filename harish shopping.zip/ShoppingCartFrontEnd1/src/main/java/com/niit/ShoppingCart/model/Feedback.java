package com.niit.ShoppingCart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table
@Component
public class Feedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int feed_id;
	private String feed_name;
	private String feed_email;
	
	private String feed;
	public int getFeed_id() {
		return feed_id;
	}
	public void setFeed_id(int feed_id) {
		this.feed_id = feed_id;
	}
	public String getFeed_name() {
		return feed_name;
	}
	public void setFeed_name(String feed_name) {
		this.feed_name = feed_name;
	}
	public String getFeed_email() {
		return feed_email;
	}
	public void setFeed_email(String feed_email) {
		this.feed_email = feed_email;
	}
	public String getFeed() {
		return feed;
	}
	public void setFeed(String feed) {
		this.feed = feed;
	}
	
	
}
