package com.niit.ShoppingCart.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.ShoppingCart.model.Feedback;

@Repository("feedbackDAO")
public class FeedbackDAOImpl implements FeedbackDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	public FeedbackDAOImpl(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
	}
	
	
	@Transactional
	public boolean save(Feedback feedback)
	{
		try {
			sessionFactory.getCurrentSession().save(feedback);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Feedback> feedlist()
	{
		String hql = " from Feedback";
		
		@SuppressWarnings("rawtypes")
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		List<Feedback> list = query.list();
		
		if(list==null || list.isEmpty())
		{
			return null;
		}
		
		return query.list();
	}

	
	@Transactional
	public List<Feedback> somefeed()
	{
		String hql = "from Feedback order by feed_id desc";
		
		@SuppressWarnings("rawtypes")
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		query.setFirstResult(0).setMaxResults(4);
		
		@SuppressWarnings("unchecked")
		List<Feedback> somefeedlist = query.list();
		
		if(somefeedlist!=null || !somefeedlist.isEmpty())
		{
			return somefeedlist;
		}
		return null;
	}

}
